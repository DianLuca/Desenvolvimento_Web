Com o intuito de melhorar suas vendas, a empresa i-design decidiu contratar uma
agência de desenvolvimento de sistemas para a construção de um site
institucional. A i-design trabalha no ramo de projetos arquitetônicos e preza por
um design clean. Para o site, você deverá construir 5 páginas, com a seguinte
navegação: Home, Sobre, Portfólio, Clientes e Contato. Utilize todo o conhecimento
adquirido até o momento para criar algo bonito e satisfatório.